
jcsirot/sonarqube
===========

# Install

kpm deploy jcsirot/sonarqube

